
Create a new conda environment called IdealDataInterface via

conda env create -f environment.yml

source activate IdealDataInterface

see example code / Jupyter notebook for usage

or try example device usage display:
 python Python/devicedata_example.py --inputdir ./SMILE --homeid 1868

